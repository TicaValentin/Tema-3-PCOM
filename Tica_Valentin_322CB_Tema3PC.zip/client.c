#include <stdio.h>      /* printf, sprintf */
#include <stdlib.h>     /* exit, atoi, malloc, free */
#include <unistd.h>     /* read, write, close */
#include <string.h>     /* memcpy, memset */
#include <sys/socket.h> /* socket, connect */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <netdb.h>      /* struct hostent, gethostbyname */
#include <arpa/inet.h>
#include <jansson.h>
#include <stdbool.h>
#include "helpers.h"
#include "requests.h"

// definirea porturilor si a tuturor datelor 
// valabile in permanenta
#define BUFFER_LEN 4096
#define SERVER_IP "34.254.242.81"
#define SERVER_PORT 8080
#define REGISTER "/api/v1/tema/auth/register"
#define LOGIN "/api/v1/tema/auth/login"
#define ACCESS "/api/v1/tema/library/access"
#define GET_BOOKS "/api/v1/tema/library/books"
#define LOGOUT "/api/v1/tema/auth/logout"

#define JSON1 "application/json"

// enum pentru identificarea fiecarei comenzi
// si pentru aspect mai lizibil
typedef enum {
    CMD_EXIT,
    CMD_REGISTER,
    CMD_LOGIN,
    CMD_ENTER_LIBRARY,
    CMD_GET_BOOKS,
    CMD_GET_BOOK,
    CMD_ADD_BOOK,
    CMD_DELETE_BOOK,
    CMD_LOGOUT,
    CMD_INVALID
} CommandType;

// functie ajutatoare pentru determinarea comenzii
CommandType get_command_type(const char *buffer) {
    if (strcmp(buffer, "exit") == 0) {
        return CMD_EXIT;
    } else if (strcmp(buffer, "register") == 0) {
        return CMD_REGISTER;
    } else if (strcmp(buffer, "login") == 0) {
        return CMD_LOGIN;
    } else if (strcmp(buffer, "enter_library") == 0) {
        return CMD_ENTER_LIBRARY;
    } else if (strcmp(buffer, "get_books") == 0) {
        return CMD_GET_BOOKS;
    } else if (strcmp(buffer, "get_book") == 0) {
        return CMD_GET_BOOK;
    } else if (strcmp(buffer, "add_book") == 0) {
        return CMD_ADD_BOOK;
    } else if (strcmp(buffer, "delete_book") == 0) {
        return CMD_DELETE_BOOK;
    } else if (strcmp(buffer, "logout") == 0) {
        return CMD_LOGOUT;
    } else {
        return CMD_INVALID;
    }
}

int main(int argc, char *argv[])
{
    char *message;
    char *response;
    char *cookie = calloc(100 , sizeof(char));
    int sockfd;

    // valori boolene pentru determinarea 
    // pe parcurs a conectiunilor deja existente
    bool connected = false;
    bool librarie = false;
    char comanda[100];
    int exit = 0;

    char *cookies[1];
    // token pentru dovedirea accestului extras o data cu intrarea
    char *token = NULL;
    
    while(exit != 1){
        sockfd = open_connection(SERVER_IP, SERVER_PORT, AF_INET, SOCK_STREAM, 0);

        fgets(comanda, 100, stdin);
        comanda[strcspn(comanda, "\n")] = 0;

        CommandType command = get_command_type(comanda);
        switch (command)
        {
            case CMD_EXIT: {
                // Handle exit command.
                exit = 1;
                printf("Pa!\n");
                break;
            }
            case CMD_REGISTER: {
                // citesc usernameul si parola
                char *user = malloc(100 * sizeof(char));
                char *pass = malloc(100 * sizeof(char));

                printf("username=");
                scanf("%s", user);

                printf("password=");
                scanf("%s", pass);

                char *json_format = "{\n\t\"username\": \"%s\",\n\t\"password\": \"%s\"\n}";

                // Obținem lungimea șirului JSON
                int json_length = snprintf(NULL, 0, json_format, user, pass) + 1;

                // Alocam memoria necesară
                char *json_string = malloc(json_length);

                if (json_string == NULL) {
                    printf("Eroare la alocarea memoriei.\n");
                    return 1;
                }

                // Cream șirul JSON
                snprintf(json_string, json_length, json_format, user, pass);
                char *utilizator[1];
                utilizator[0] = malloc(strlen(json_string) + 1);
                strcpy(utilizator[0], json_string);
                message = compute_post_request(SERVER_IP, REGISTER, JSON1, utilizator, 1, NULL, 0, token);
	            send_to_server(sockfd, message);

	            response = receive_from_server(sockfd);

                if(strstr(response, "400") != NULL) {
                    printf("400 - BAD TAKEN USERNAME!\n");
                } else {
                    printf("200 - OK - Utilizator înregistrat cu succes!\n");
                }

                free(json_string);
                break;
            }
            case CMD_LOGIN: {
                if(connected == false) {
                    // Handle login command.
                    connected = true;
                    librarie = false;
                    // citesc usernameul si parola
                    char *user = malloc(100 * sizeof(char));
                    char *pass = malloc(100 * sizeof(char));

                    printf("username=");
                    scanf("%s", user);

                    printf("password=");
                    scanf("%s", pass);

                    char *json_format = "{\n\t\"username\": \"%s\",\n\t\"password\": \"%s\"\n}";

                    // Obținem lungimea șirului JSON
                    int json_length = snprintf(NULL, 0, json_format, user, pass) + 1;

                    // Alocam memoria necesară
                    char *json_string = malloc(json_length);

                    if (json_string == NULL) {
                        printf("Eroare la alocarea memoriei.\n");
                        return 1;
                    }

                    // Cream șirul JSON
                    snprintf(json_string, json_length, json_format, user, pass);
                    char *utilizator[1];
                    utilizator[0] = malloc(strlen(json_string) + 1);
                    strcpy(utilizator[0], json_string);

                    message = compute_post_request(SERVER_IP, LOGIN, JSON1, utilizator, 1, NULL, 0, token);
	                send_to_server(sockfd, message);

	                response = receive_from_server(sockfd);

                    if(strstr(response,"400") != NULL){
                        printf("400 - BAD");
                        if(strstr(response, "No account") != NULL)
                            printf(" No account with this username!\n");
                        else
                            printf(" Credentials are not good!\n");
                        connected = false;
                        librarie = false;
                        continue;
                    }

                    // obtinerea cookie ului din raspunsul primit de la server
                    response = strstr(response, "Set-Cookie: ");            
                    strtok(response, ";");
                    response += strlen("Set-Cookie: ");
                    strcpy(cookie, response);
                    cookies[0] = response;

                    if(cookie != NULL){
                        printf("Logare cu succes!\n");
                    }

                    free(json_string);
                } else {
                    printf("Suntem deja conectati, trebuie logout!\n");
                }
                break;
            }
            case CMD_ENTER_LIBRARY: {
                // Handle enter_library command.
                if(connected == true){
                    librarie = true;
                    if (token != NULL) {
                        printf("Sunteți deja autentificat și aveți acces în bibliotecă.\n");
                        continue;
                    }

                    message = compute_get_request(SERVER_IP, ACCESS, NULL, cookies, 1, NULL);
                    send_to_server(sockfd, message);
                    //obtinera tokenului
                    response = receive_from_server(sockfd);
                    response = strstr(response, "token");
                    response += 8;
                    response[strlen(response) - 2] = '\0';
                    token = malloc(strlen(response) + 1);
                    strcpy(token, response);
                    // printf("%s\n", token);
                    printf("Token created, Enter Library succes!\n");
                } else {
                    printf("Nu s-a putut realiza accesul in biblioteca. Nu suntem conectati\n ");
                }
                break;
            }
            case CMD_GET_BOOKS: {
                // Handle get_books command.
                if(librarie == true){
                    // accesul se realizeaza doar daca suntem intrati in librarie
                    message = compute_get_request(SERVER_IP, GET_BOOKS, NULL, cookies, 1, token);
                    send_to_server(sockfd, message);
                    // cautam in cartile din biblioteca si daca id ul cartii exista
                    // si printam ce ni se intoarce
                    response = receive_from_server(sockfd);
                    response = strchr(response, '[');
                    printf("%s\n", response);
                } else {
                    printf("Nu suntem intrati in librarie\n");
                }
                break;
            }
            case CMD_GET_BOOK: {
                // Handle get_book command.
                if (librarie == true){
                    int id = 0;
                    printf("id=");
                    scanf("%d", &id);
                    if(id < 0){
                        printf("Numar negativ\n");
                        continue;
                    }

                    char *id_str = malloc(100 * sizeof(char));
                    sprintf(id_str, "%d", id);
                    char *path = malloc(strlen(GET_BOOKS) + 1 + strlen(id_str));
                    sprintf(path, "%s/%s",GET_BOOKS,id_str);
                    free(id_str);
                    // printf("%s\n\n", path);

                    message = compute_get_request(SERVER_IP, path, NULL, cookies, 1, token);
                    send_to_server(sockfd, message);

                    response = receive_from_server(sockfd);
                    // printf("%s\n", response);

                    if(strstr(response, "No book") != NULL){
                        printf("Cartea nu exista\n");
                    } else {
                        printf("%s\n",strstr(response, "{"));
                    }
                    
                } else {
                    printf("Nu suntem intrati in librarie\n");
                }    
                break;
            }
            case CMD_ADD_BOOK: {
                // Handle add_book command.
                if(librarie == true) {
                    char* title, *author, *genre, *publisher;
                    int pages = 0;
                    title = calloc(100, sizeof(char));
                    author = calloc(100, sizeof(char));
                    publisher = calloc(100, sizeof(char));
                    genre = calloc(100, sizeof(char));

                    printf("title=");
                    scanf("%s", title);

                    printf("author=");
                    scanf("%s", author);

                    printf("genre=");
                    scanf("%s", genre);

                    printf("page_count=");
                    scanf("%d",&pages);

                    printf("publisher=");
                    scanf("%s", publisher);

                    if(strlen(title) == 0 || strlen(author) == 0 || strlen(genre) == 0 || strlen(publisher) == 0 || pages < 0){
                        printf("Format gresit!\n");
                        continue;
                    }


                    // Definim formatul JSON
                    char *json_format = "{\n\t\"title\": \"%s\",\n\t\"author\": \"%s\",\n\t\"genre\": \"%s\",\n\t\"page_count\": %d,\n\t\"publisher\": \"%s\"\n}";

                    // Obținem lungimea șirului JSON
                    int json_length = snprintf(NULL, 0, json_format, title, author, genre, pages, publisher) + 1;

                    // Alocam memoria necesară
                    char *json_string = malloc(json_length);

                    if (json_string == NULL) {
                        printf("Eroare la alocarea memoriei.\n");
                        return 1;
                    }
                    char *json_send[1];
                    // Cream șirul JSON
                    snprintf(json_string, json_length, json_format, title, author, genre, pages, publisher);
                    json_send[0] = malloc(strlen(json_string) + 1);
                    strcpy(json_send[0], json_string);
                    message = compute_post_request(SERVER_IP, GET_BOOKS, JSON1, json_send, 1, NULL, 0, token);
                    send_to_server(sockfd, message);

                    response = receive_from_server(sockfd);
                    printf("Adaugare reusita");
                } else {
                    printf("Nu intrati in biblioteca");
                }
                break;
            }
            case CMD_DELETE_BOOK: {
                // Handle delete_book command.
                if(librarie == true){
                    int id = 0;
                    printf("id=");
                    scanf("%d", &id);

                    if(id < 0){
                        printf("Numar negativ\n");
                        continue;
                    }

                    char *id_str = malloc(100 * sizeof(char));
                    sprintf(id_str, "%d", id);
                    char *path = malloc(strlen(GET_BOOKS) + 1 + strlen(id_str));
                    sprintf(path, "%s/%s",GET_BOOKS,id_str);
                    free(id_str);

                    message = compute_delete_request(SERVER_IP, path, NULL, cookies, 1, token);
                    send_to_server(sockfd, message);

                    response = receive_from_server(sockfd);
                    if(strstr(response, "error") != NULL) {
                        printf("Cartea este inexistenta\n");
                    } else {
                        printf("Delete succes!\n");
                    }
                } else {
                    printf("Nu avem acces la biblioteca\n");
                }
                break;
            }
            case CMD_LOGOUT: {
                // Handle logout command.
                if(connected == true) {
                    connected = false;
                    librarie = false;
                    free(token);
                    token = NULL;
                    message = compute_get_request(SERVER_IP, LOGOUT, NULL, cookies, 1, token);
                    send_to_server(sockfd, message);

                    response = receive_from_server(sockfd);
                    printf("Succes!\n");
                } else {
                    printf("Nu suntem conectati.\n");
                }
                break;
            }
            default: {
                break;
            }
        }
        //inchidem conexiunea deschisa
        close_connection(sockfd);
    }

    return 0;
}
